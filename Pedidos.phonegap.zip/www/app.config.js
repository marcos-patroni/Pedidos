// NOTE object below must be a valid JSON
window.Pedidos = $.extend(true, window.Pedidos, {
  "config": {
    "layoutSet": "navbar",
    "navigation": [
      {
        "title": "In�cio",
        "onExecute": "#home",
        "icon": "home"
      },
      {
        "title": "Teste",
        "onExecute": "#Teste",
        "icon": "Teste"
      },
      {
        "title": "Sobre",
        "onExecute": "#Sobre",
        "icon": "info"
      }
    ]
  }
});