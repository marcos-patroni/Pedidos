﻿window.Pedidos = window.Pedidos || {};

$(function() {
    // Uncomment the line below to disable platform-specific look and feel and to use the Generic theme for all devices
    // DevExpress.devices.current({ platform: "generic" });
    // To customize the Generic theme, use the DevExtreme Theme Builder (http://js.devexpress.com/ThemeBuilder)
    // For details on how to use themes and the Theme Builder, refer to the http://js.devexpress.com/Documentation/Howto/Themes article

    $(document).on("deviceready", function () {
        navigator.splashscreen.hide();
        if(window.devextremeaddon) {
            window.devextremeaddon.setup();
        }
        $(document).on("backbutton", function () {
            DevExpress.processHardwareBackButton();
        });
    });

    function onNavigatingBack(e) {
        if (e.isHardwareButton && !Pedidos.app.canBack()) {
            e.cancel = true;
            exitApp();
        }
    }

    function exitApp() {
        switch (DevExpress.devices.real().platform) {
            case "tizen":
                tizen.application.getCurrentApplication().exit();
                break;
            case "android":
                navigator.app.exitApp();
                break;
            case "win8":
                window.external.Notify("DevExpress.ExitApp");
                break;
        }
    }


    Pedidos.app = new DevExpress.framework.html.HtmlApplication({
        namespace: Pedidos,
        layoutSet: DevExpress.framework.html.layoutSets[Pedidos.config.layoutSet],
        navigation: Pedidos.config.navigation,
        commandMapping: Pedidos.config.commandMapping
    });
    Pedidos.app.router.register(":view/:id", { view: "home", id: undefined });
    Pedidos.app.on("navigatingBack", onNavigatingBack);
    Pedidos.app.navigate();
});
