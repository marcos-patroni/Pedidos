﻿Pedidos.Sobre = function (params) {

    var viewModel = {
//  Put the binding properties here
    };

    return viewModel;
};